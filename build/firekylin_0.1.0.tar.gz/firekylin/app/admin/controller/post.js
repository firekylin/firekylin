'use strict';

exports.__esModule = true;

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _typeof2 = require('babel-runtime/helpers/typeof');

var _typeof3 = _interopRequireDefault(_typeof2);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _getIterator2 = require('babel-runtime/core-js/get-iterator');

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = require('babel-runtime/helpers/inherits');

var _inherits3 = _interopRequireDefault(_inherits2);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _apiBase = require('./apiBase');

var _apiBase2 = _interopRequireDefault(_apiBase);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _class = function (_base) {
  (0, _inherits3.default)(_class, _base);

  function _class() {
    (0, _classCallCheck3.default)(this, _class);
    return (0, _possibleConstructorReturn3.default)(this, _base.apply(this, arguments));
  }

  _class.prototype.getAction = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee() {
      var data, posts, postTags, tags, _iterator, _isArray, _i, _ref, postTag, _iterator2, _isArray2, _i2, _ref2, tag, page, pageCount, ids, _tags, _iterator3, _isArray3, _i3, _ref3, post, tid, _iterator4, _isArray4, _i4, _ref4, _tag, _iterator5, _isArray5, _i5, _ref5, nPost;

      return _regenerator2.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              data = void 0;
              posts = [];

              if (!this.id) {
                _context.next = 47;
                break;
              }

              _context.next = 5;
              return this.model('post_tag').where({ post_id: this.id }).select();

            case 5:
              postTags = _context.sent;
              _context.next = 8;
              return this.model('tag').select();

            case 8:
              tags = _context.sent;
              _context.next = 11;
              return this.modelInstance.where({ id: this.id }).find();

            case 11:
              data = _context.sent;
              _context.next = 14;
              return this.model('category').where({ id: data.category_id }).getField('id', true);

            case 14:
              data.category = _context.sent;

              data.tags = '';

              _iterator = postTags, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : (0, _getIterator3.default)(_iterator);

            case 17:
              if (!_isArray) {
                _context.next = 23;
                break;
              }

              if (!(_i >= _iterator.length)) {
                _context.next = 20;
                break;
              }

              return _context.abrupt('break', 45);

            case 20:
              _ref = _iterator[_i++];
              _context.next = 27;
              break;

            case 23:
              _i = _iterator.next();

              if (!_i.done) {
                _context.next = 26;
                break;
              }

              return _context.abrupt('break', 45);

            case 26:
              _ref = _i.value;

            case 27:
              postTag = _ref;
              _iterator2 = tags, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : (0, _getIterator3.default)(_iterator2);

            case 29:
              if (!_isArray2) {
                _context.next = 35;
                break;
              }

              if (!(_i2 >= _iterator2.length)) {
                _context.next = 32;
                break;
              }

              return _context.abrupt('break', 43);

            case 32:
              _ref2 = _iterator2[_i2++];
              _context.next = 39;
              break;

            case 35:
              _i2 = _iterator2.next();

              if (!_i2.done) {
                _context.next = 38;
                break;
              }

              return _context.abrupt('break', 43);

            case 38:
              _ref2 = _i2.value;

            case 39:
              tag = _ref2;

              if (tag['id'] == postTag['tag_id']) {
                data.tags += ' ' + tag['name'];
              }

            case 41:
              _context.next = 29;
              break;

            case 43:
              _context.next = 17;
              break;

            case 45:
              _context.next = 107;
              break;

            case 47:
              page = this.get('page') || 1;
              pageCount = this.get('page_count') || 20;
              ids = [];
              _context.next = 52;
              return this.model('tag').select();

            case 52:
              _tags = _context.sent;
              _context.next = 55;
              return this.modelInstance.alias('post').field('`post`.*, `category`.`name` as "category", `user`.`username` as "user", `pTag`.`tag_id` as "tid"').join([{
                table: 'category',
                as: 'category',
                on: ['`post`.`category_id`', '`category`.`id`']
              }, {
                table: 'user',
                as: 'user',
                on: ['`post`.`user_id`', '`user`.`id`']
              }, {
                table: 'post_tag',
                as: 'pTag',
                on: ['`pTag`.`post_id`', '`post`.`id`']
              }]).where({ 'post.status': ['IN', '1,2'] }).order('`date` DESC').limit((page - 1) * pageCount, pageCount).select();

            case 55:
              data = _context.sent;
              _iterator3 = data, _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : (0, _getIterator3.default)(_iterator3);

            case 57:
              if (!_isArray3) {
                _context.next = 63;
                break;
              }

              if (!(_i3 >= _iterator3.length)) {
                _context.next = 60;
                break;
              }

              return _context.abrupt('break', 106);

            case 60:
              _ref3 = _iterator3[_i3++];
              _context.next = 67;
              break;

            case 63:
              _i3 = _iterator3.next();

              if (!_i3.done) {
                _context.next = 66;
                break;
              }

              return _context.abrupt('break', 106);

            case 66:
              _ref3 = _i3.value;

            case 67:
              post = _ref3;
              tid = post['tid'];
              //获取标签名称

              _iterator4 = _tags, _isArray4 = Array.isArray(_iterator4), _i4 = 0, _iterator4 = _isArray4 ? _iterator4 : (0, _getIterator3.default)(_iterator4);

            case 70:
              if (!_isArray4) {
                _context.next = 76;
                break;
              }

              if (!(_i4 >= _iterator4.length)) {
                _context.next = 73;
                break;
              }

              return _context.abrupt('break', 84);

            case 73:
              _ref4 = _iterator4[_i4++];
              _context.next = 80;
              break;

            case 76:
              _i4 = _iterator4.next();

              if (!_i4.done) {
                _context.next = 79;
                break;
              }

              return _context.abrupt('break', 84);

            case 79:
              _ref4 = _i4.value;

            case 80:
              _tag = _ref4;

              if (_tag['id'] == tid) {
                post['tags'] = _tag['name'];
              }

            case 82:
              _context.next = 70;
              break;

            case 84:
              if (!(ids.indexOf(post.id) > -1)) {
                _context.next = 102;
                break;
              }

              _iterator5 = posts, _isArray5 = Array.isArray(_iterator5), _i5 = 0, _iterator5 = _isArray5 ? _iterator5 : (0, _getIterator3.default)(_iterator5);

            case 86:
              if (!_isArray5) {
                _context.next = 92;
                break;
              }

              if (!(_i5 >= _iterator5.length)) {
                _context.next = 89;
                break;
              }

              return _context.abrupt('break', 100);

            case 89:
              _ref5 = _iterator5[_i5++];
              _context.next = 96;
              break;

            case 92:
              _i5 = _iterator5.next();

              if (!_i5.done) {
                _context.next = 95;
                break;
              }

              return _context.abrupt('break', 100);

            case 95:
              _ref5 = _i5.value;

            case 96:
              nPost = _ref5;

              if (nPost.id == post.id) {
                nPost.tags += ' ' + post.tags;
              }

            case 98:
              _context.next = 86;
              break;

            case 100:
              _context.next = 104;
              break;

            case 102:
              ids.push(post.id);
              posts.push(post);

            case 104:
              _context.next = 57;
              break;

            case 106:
              data = posts;

            case 107:
              return _context.abrupt('return', this.success(data));

            case 108:
            case 'end':
              return _context.stop();
          }
        }
      }, _callee, this);
    }));
    return function getAction() {
      return ref.apply(this, arguments);
    };
  }();

  _class.prototype.postAction = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee2() {
      var data, category_id, categoryModel, date, author, insertId, addOpts, tags, _iterator6, _isArray6, _i6, _ref6, tag;

      return _regenerator2.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              data = this.post();

              if (!think.isEmpty(data)) {
                _context2.next = 3;
                break;
              }

              return _context2.abrupt('return', this.fail('data is empty'));

            case 3:
              category_id = data.category;

              if (data.newCategory) {
                categoryModel = this.model('category');

                category_id = categoryModel.add({ name: data.newCategory });
              }

              date = (0, _moment2.default)().format('YYYY-MM-DD[T]HH:mm:ss');
              author = this.userInfo.id;
              _context2.next = 9;
              return this.modelInstance.add({
                category_id: category_id,
                date: date,
                status: data.status,
                user_id: author,
                title: data.title,
                content: data.content,
                modify_date: date,
                modify_user_id: author
              });

            case 9:
              insertId = _context2.sent;


              //增加post_tag关系表
              addOpts = [];
              tags = data.tags;

              if (!((typeof tags === 'undefined' ? 'undefined' : (0, _typeof3.default)(tags)) == "object")) {
                _context2.next = 30;
                break;
              }

              _iterator6 = tags, _isArray6 = Array.isArray(_iterator6), _i6 = 0, _iterator6 = _isArray6 ? _iterator6 : (0, _getIterator3.default)(_iterator6);

            case 14:
              if (!_isArray6) {
                _context2.next = 20;
                break;
              }

              if (!(_i6 >= _iterator6.length)) {
                _context2.next = 17;
                break;
              }

              return _context2.abrupt('break', 28);

            case 17:
              _ref6 = _iterator6[_i6++];
              _context2.next = 24;
              break;

            case 20:
              _i6 = _iterator6.next();

              if (!_i6.done) {
                _context2.next = 23;
                break;
              }

              return _context2.abrupt('break', 28);

            case 23:
              _ref6 = _i6.value;

            case 24:
              tag = _ref6;

              addOpts.push({
                post_id: insertId,
                tag_id: tag,
                status: data.status
              });

            case 26:
              _context2.next = 14;
              break;

            case 28:
              _context2.next = 31;
              break;

            case 30:
              if (typeof tags == "string") {
                addOpts.push({
                  post_id: insertId,
                  tag_id: tags,
                  status: data.status
                });
              } else {
                addOpts.push({
                  post_id: insertId,
                  tag_id: 0,
                  status: data.status
                });
              }

            case 31:
              _context2.next = 33;
              return this.model('post_tag').addMany(addOpts);

            case 33:
              return _context2.abrupt('return', this.success({ id: insertId }));

            case 34:
            case 'end':
              return _context2.stop();
          }
        }
      }, _callee2, this);
    }));
    return function postAction() {
      return ref.apply(this, arguments);
    };
  }();

  _class.prototype.putAction = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee3() {
      var data, rows, addOpts, tags, _iterator7, _isArray7, _i7, _ref7, tag;

      return _regenerator2.default.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              if (this.id) {
                _context3.next = 2;
                break;
              }

              return _context3.abrupt('return', this.fail('params error'));

            case 2:
              data = this.post();
              //更新文章内容

              if (!think.isEmpty(data)) {
                _context3.next = 5;
                break;
              }

              return _context3.abrupt('return', this.fail('data is empty'));

            case 5:
              delete data.id;

              (0, _assign2.default)(data, {
                modify_date: (0, _moment2.default)().format('YYYY-MM-DD[T]HH:mm:ss'),
                modify_user_id: this.userInfo.id,
                category_id: data.category
              });
              delete data.category;

              _context3.next = 10;
              return this.modelInstance.where({ id: this.id }).update(data);

            case 10:
              rows = _context3.sent;

              //更新post_tag关系表
              addOpts = [];
              tags = data.tags;

              if (!((typeof tags === 'undefined' ? 'undefined' : (0, _typeof3.default)(tags)) == "object")) {
                _context3.next = 31;
                break;
              }

              _iterator7 = tags, _isArray7 = Array.isArray(_iterator7), _i7 = 0, _iterator7 = _isArray7 ? _iterator7 : (0, _getIterator3.default)(_iterator7);

            case 15:
              if (!_isArray7) {
                _context3.next = 21;
                break;
              }

              if (!(_i7 >= _iterator7.length)) {
                _context3.next = 18;
                break;
              }

              return _context3.abrupt('break', 29);

            case 18:
              _ref7 = _iterator7[_i7++];
              _context3.next = 25;
              break;

            case 21:
              _i7 = _iterator7.next();

              if (!_i7.done) {
                _context3.next = 24;
                break;
              }

              return _context3.abrupt('break', 29);

            case 24:
              _ref7 = _i7.value;

            case 25:
              tag = _ref7;

              addOpts.push({
                post_id: this.id,
                tag_id: tag,
                status: data.status
              });

            case 27:
              _context3.next = 15;
              break;

            case 29:
              _context3.next = 32;
              break;

            case 31:
              if (typeof tags == "string") {
                addOpts.push({
                  post_id: this.id,
                  tag_id: tags,
                  status: data.status
                });
              } else {
                addOpts.push({
                  post_id: this.id,
                  tag_id: 0,
                  status: data.status
                });
              }

            case 32:
              _context3.next = 34;
              return this.model('post_tag').where({ post_id: this.id }).delete();

            case 34:
              _context3.next = 36;
              return this.model('post_tag').addMany(addOpts);

            case 36:
              return _context3.abrupt('return', this.success({ id: this.id }));

            case 37:
            case 'end':
              return _context3.stop();
          }
        }
      }, _callee3, this);
    }));
    return function putAction() {
      return ref.apply(this, arguments);
    };
  }();

  _class.prototype.deleteAction = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee4() {
      var ids, rows;
      return _regenerator2.default.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              if (this.id) {
                _context4.next = 2;
                break;
              }

              return _context4.abrupt('return', this.fail('params error'));

            case 2:
              ids = this.id.toString().split(',');
              _context4.next = 5;
              return this.modelInstance.where({ id: ['in', ids] }).delete();

            case 5:
              rows = _context4.sent;
              _context4.next = 8;
              return this.model('post_tag').where({ post_id: ['in', ids] }).delete();

            case 8:
              return _context4.abrupt('return', this.success({ id: this.id }));

            case 9:
            case 'end':
              return _context4.stop();
          }
        }
      }, _callee4, this);
    }));
    return function deleteAction() {
      return ref.apply(this, arguments);
    };
  }();

  return _class;
}(_apiBase2.default);

exports.default = _class;