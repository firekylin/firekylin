'use strict';
/**
 * config
 */

exports.__esModule = true;
exports.default = {
  resource_reg: /^(static\/|theme\/|[^\/]+\.(?!js|html)\w+$)/
  //key: value
};