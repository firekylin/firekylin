'use strict';
/**
 * relation model
 */

exports.__esModule = true;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = require('babel-runtime/helpers/inherits');

var _inherits3 = _interopRequireDefault(_inherits2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _class = function (_think$model$relation) {
	(0, _inherits3.default)(_class, _think$model$relation);

	function _class() {
		(0, _classCallCheck3.default)(this, _class);
		return (0, _possibleConstructorReturn3.default)(this, _think$model$relation.apply(this, arguments));
	}

	_class.prototype.init = function init() {
		var _think$model$relation2;

		for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
			args[_key] = arguments[_key];
		}

		(_think$model$relation2 = _think$model$relation.prototype.init).call.apply(_think$model$relation2, [this].concat(args));
	};

	_class.prototype.afterUpdate = function () {
		var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee(data, options) {
			return _regenerator2.default.wrap(function _callee$(_context) {
				while (1) {
					switch (_context.prev = _context.next) {
						case 0:
							_context.next = 2;
							return _think$model$relation.prototype.afterUpdate.call(this, data, options);

						case 2:
							return _context.abrupt('return', this.listcount());

						case 3:
						case 'end':
							return _context.stop();
					}
				}
			}, _callee, this);
		}));

		function afterUpdate(_x, _x2) {
			return ref.apply(this, arguments);
		}

		return afterUpdate;
	}();

	_class.prototype.afterDelete = function () {
		var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee2(data, options) {
			return _regenerator2.default.wrap(function _callee2$(_context2) {
				while (1) {
					switch (_context2.prev = _context2.next) {
						case 0:
							_context2.next = 2;
							return _think$model$relation.prototype.afterDelete.call(this, data, options);

						case 2:
							return _context2.abrupt('return', this.listcount());

						case 3:
						case 'end':
							return _context2.stop();
					}
				}
			}, _callee2, this);
		}));

		function afterDelete(_x3, _x4) {
			return ref.apply(this, arguments);
		}

		return afterDelete;
	}();

	_class.prototype.afterAdd = function () {
		var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee3(data, options) {
			return _regenerator2.default.wrap(function _callee3$(_context3) {
				while (1) {
					switch (_context3.prev = _context3.next) {
						case 0:
							_context3.next = 2;
							return _think$model$relation.prototype.afterAdd.call(this, data, options);

						case 2:
							return _context3.abrupt('return', this.listcount());

						case 3:
						case 'end':
							return _context3.stop();
					}
				}
			}, _callee3, this);
		}));

		function afterAdd(_x5, _x6) {
			return ref.apply(this, arguments);
		}

		return afterAdd;
	}();

	_class.prototype.listcount = function () {
		var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee4() {
			var count, length, i;
			return _regenerator2.default.wrap(function _callee4$(_context4) {
				while (1) {
					switch (_context4.prev = _context4.next) {
						case 0:
							_context4.next = 2;
							return this.model("post").where({
								is_public: 1, //公开
								type: 0, //文章
								status: 3 //已经发布
							}).count();

						case 2:
							count = _context4.sent;

							//情况缓存
							length = Math.ceil(count / 10);
							i = 0;

						case 5:
							if (!(i < length)) {
								_context4.next = 11;
								break;
							}

							_context4.next = 8;
							return think.cache('page' + (i ? i : 1), null);

						case 8:
							i++;
							_context4.next = 5;
							break;

						case 11:
						case 'end':
							return _context4.stop();
					}
				}
			}, _callee4, this);
		}));

		function listcount() {
			return ref.apply(this, arguments);
		}

		return listcount;
	}();

	return _class;
}(think.model.relation);

exports.default = _class;