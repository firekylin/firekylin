'use strict';

var _nodeCrontab = require('node-crontab');

var _nodeCrontab2 = _interopRequireDefault(_nodeCrontab);

require('./crontab');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

if (!think.cli) {

  _nodeCrontab2.default.scheduleJob("0 */3 * * *", function () {
    if (!firekylin.isInstalled) {
      return;
    }
    think.http("/crontab/sitemap", true);
  });

  _nodeCrontab2.default.scheduleJob("0 */1 * * *", function () {
    if (!firekylin.isInstalled) {
      return;
    }
    think.http("/crontab/sync_comment", true);
  });
}