'use strict';

exports.__esModule = true;

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _getIterator2 = require('babel-runtime/core-js/get-iterator');

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = require('babel-runtime/helpers/inherits');

var _inherits3 = _interopRequireDefault(_inherits2);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _class = function (_think$service$base) {
  (0, _inherits3.default)(_class, _think$service$base);

  function _class() {
    (0, _classCallCheck3.default)(this, _class);
    return (0, _possibleConstructorReturn3.default)(this, _think$service$base.apply(this, arguments));
  }

  /**
   * init
   * @param  {[type]} info [description]
   * @return {[type]}      [description]
   */

  _class.prototype.init = function init(dbConfig, accountConfig, ip) {
    this.dbConfig = dbConfig;
    this.dbConfig.type = 'mysql';
    this.accountConfig = accountConfig;
    this.ip = ip;
  };
  /**
   * get model
   * @return {[type]} [description]
   */


  _class.prototype.getModel = function getModel(name, module) {
    var dbConfig = void 0;
    if (name === true) {
      dbConfig = think.extend({}, this.dbConfig);
      dbConfig.database = '';
      name = '';
    } else {
      dbConfig = this.dbConfig;
    }
    return this.model(name || 'user', {
      adapter: {
        mysql: dbConfig
      }
    }, module);
  };
  /**
   * 
   * @return {[type]} [description]
   */


  _class.prototype.checkDbInfo = function checkDbInfo() {
    var dbInstance = this.getModel(true);
    return dbInstance.query('SELECT VERSION()').catch(function () {
      return _promise2.default.reject('数据库信息有误');
    });
  };
  /**
   * insert data
   * @return {[type]} [description]
   */


  _class.prototype.insertData = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee2() {
      var _this2 = this;

      var model, dbExist, dbFile, content, promises, optionsModel, salt;
      return _regenerator2.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              model = this.getModel(true);
              _context2.next = 3;
              return model.query("SELECT `TABLE_NAME` FROM `INFORMATION_SCHEMA`.`TABLES` WHERE `TABLE_SCHEMA`='" + this.dbConfig.database + "'");

            case 3:
              dbExist = _context2.sent;

              if (!think.isEmpty(dbExist)) {
                _context2.next = 8;
                break;
              }

              _context2.next = 7;
              return model.query('CREATE DATABASE `' + this.dbConfig.database + '`').catch(function () {});

            case 7:
              model.close();

            case 8:
              dbFile = think.ROOT_PATH + think.sep + 'firekylin.sql';

              if (think.isFile(dbFile)) {
                _context2.next = 11;
                break;
              }

              return _context2.abrupt('return', _promise2.default.reject('数据库文件（firekylin.sql）不存在，请重新下载'));

            case 11:
              content = _fs2.default.readFileSync(dbFile, 'utf8');

              content = content.replace(/\#[^\n]*/g, '').replace(/\/\*.*?\*\//g, '').replace(/\n/g, ' ');
              content = content.replace(/fk_/g, this.dbConfig.prefix || '');

              model = this.getModel();
              _context2.next = 17;
              return model.transaction((0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee() {
                var _iterator, _isArray, _i, _ref, item;

                return _regenerator2.default.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        content = content.split(';');
                        _iterator = content, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : (0, _getIterator3.default)(_iterator);

                      case 2:
                        if (!_isArray) {
                          _context.next = 8;
                          break;
                        }

                        if (!(_i >= _iterator.length)) {
                          _context.next = 5;
                          break;
                        }

                        return _context.abrupt('break', 19);

                      case 5:
                        _ref = _iterator[_i++];
                        _context.next = 12;
                        break;

                      case 8:
                        _i = _iterator.next();

                        if (!_i.done) {
                          _context.next = 11;
                          break;
                        }

                        return _context.abrupt('break', 19);

                      case 11:
                        _ref = _i.value;

                      case 12:
                        item = _ref;

                        item = item.trim();

                        if (!item) {
                          _context.next = 17;
                          break;
                        }

                        _context.next = 17;
                        return model.query(item);

                      case 17:
                        _context.next = 2;
                        break;

                      case 19:
                      case 'end':
                        return _context.stop();
                    }
                  }
                }, _callee, _this2);
              }))).catch(function (error) {
                think.log(error);
                return _promise2.default.reject('导入数据失败，请重试');
              });

            case 17:
              promises = ['cate', 'post', 'post_cate', 'post_tag', 'tag', 'user'].map(function (item) {
                return _this2.getModel(item).where('1=1').delete();
              });
              _context2.next = 20;
              return _promise2.default.all(promises);

            case 20:
              optionsModel = this.getModel('options');
              _context2.next = 23;
              return optionsModel.where('1=1').update({ value: '' });

            case 23:
              salt = think.uuid(10) + '!@#$%^&*';

              this.password_salt = salt;

              _context2.next = 27;
              return optionsModel.where({ key: 'password_salt' }).update({ value: salt });

            case 27:
              _context2.next = 29;
              return optionsModel.where({ key: 'title' }).update({ value: 'FireKylin 系统' });

            case 29:
              _context2.next = 31;
              return optionsModel.where({ key: 'logo_url' }).update({ value: '/static/img/firekylin.jpg' });

            case 31:
              _context2.next = 33;
              return optionsModel.where({ key: 'theme' }).update({ value: 'firekylin' });

            case 33:

              optionsModel.close();

            case 34:
            case 'end':
              return _context2.stop();
          }
        }
      }, _callee2, this);
    }));
    return function insertData() {
      return ref.apply(this, arguments);
    };
  }();
  /**
   * update config
   * @return {[type]} [description]
   */


  _class.prototype.updateConfig = function updateConfig() {
    var data = {
      type: 'mysql',
      adapter: {
        mysql: this.dbConfig
      }
    };
    var content = '\n      "use strict";\n      exports.__esModule = true;\n      exports.default = ' + (0, _stringify2.default)(data, undefined, 4) + '\n    ';
    var dbConfigFile = think.APP_PATH + '/common/config/db.js';
    _fs2.default.writeFileSync(dbConfigFile, content);
    think.config('db', data);
  };
  /**
   * create account
   * @return {[type]} [description]
   */


  _class.prototype.createAccount = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee3() {
      var password, model, data;
      return _regenerator2.default.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              password = think.md5(this.password_salt + this.accountConfig.password);
              model = this.getModel('user', 'admin');
              data = {
                username: this.accountConfig.username,
                password: password,
                email: '',
                type: 1,
                status: 1,
                ip: this.ip
              };
              _context3.next = 5;
              return model.addUser(data);

            case 5:
              model.close();

            case 6:
            case 'end':
              return _context3.stop();
          }
        }
      }, _callee3, this);
    }));
    return function createAccount() {
      return ref.apply(this, arguments);
    };
  }();
  /**
   * run
   * @return {[type]} [description]
   */


  _class.prototype.run = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee4() {
      var optionsModel;
      return _regenerator2.default.wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              _context4.next = 2;
              return this.checkDbInfo();

            case 2:
              _context4.next = 4;
              return this.insertData();

            case 4:
              _context4.next = 6;
              return this.createAccount();

            case 6:
              this.updateConfig();
              firekylin.setInstalled();
              optionsModel = this.getModel('options');
              _context4.next = 11;
              return optionsModel.getOptions(true);

            case 11:
              optionsModel.close();

            case 12:
            case 'end':
              return _context4.stop();
          }
        }
      }, _callee4, this);
    }));
    return function run() {
      return ref.apply(this, arguments);
    };
  }();

  return _class;
}(think.service.base);

exports.default = _class;