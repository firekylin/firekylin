'use strict';

exports.__esModule = true;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = require('babel-runtime/helpers/inherits');

var _inherits3 = _interopRequireDefault(_inherits2);

var _base = require('./base.js');

var _base2 = _interopRequireDefault(_base);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _class = function (_Base) {
  (0, _inherits3.default)(_class, _Base);

  function _class() {
    (0, _classCallCheck3.default)(this, _class);
    return (0, _possibleConstructorReturn3.default)(this, _Base.apply(this, arguments));
  }

  /**
   * get
   * @return {[type]} [description]
   */

  _class.prototype.getAction = function getAction(self) {
    this.modelInstance.field('id,name,display_name,email,type,status,create_time,last_login_time');
    return _Base.prototype.getAction.call(this, self);
  };
  /**
   * add user
   * @return {[type]} [description]
   */


  _class.prototype.postAction = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee() {
      var data, insertId;
      return _regenerator2.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              data = this.post();
              _context.next = 3;
              return this.modelInstance.addUser(data, this.ip());

            case 3:
              insertId = _context.sent;
              return _context.abrupt('return', this.success({ id: insertId }));

            case 5:
            case 'end':
              return _context.stop();
          }
        }
      }, _callee, this);
    }));
    return function postAction() {
      return ref.apply(this, arguments);
    };
  }();
  /**
   * update user info
   * @return {[type]} [description]
   */


  _class.prototype.putAction = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee2() {
      var type, userInfo, _rows, data, rows;

      return _regenerator2.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              type = this.get('type');
              //save password

              if (!(type === 'savepwd')) {
                _context2.next = 7;
                break;
              }

              userInfo = this.userInfo;
              _context2.next = 5;
              return this.modelInstance.saveUser({
                password: this.post('password'),
                id: userInfo.id
              }, this.ip());

            case 5:
              _rows = _context2.sent;
              return _context2.abrupt('return', this.success(_rows));

            case 7:
              if (this.id) {
                _context2.next = 9;
                break;
              }

              return _context2.abrupt('return', this.fail('PARAMS_ERROR'));

            case 9:
              data = this.post();

              data.id = this.id;
              _context2.next = 13;
              return this.modelInstance.saveUser(data, this.ip());

            case 13:
              rows = _context2.sent;
              return _context2.abrupt('return', this.success({ affectedRows: rows }));

            case 15:
            case 'end':
              return _context2.stop();
          }
        }
      }, _callee2, this);
    }));
    return function putAction() {
      return ref.apply(this, arguments);
    };
  }();

  return _class;
}(_base2.default);

exports.default = _class;