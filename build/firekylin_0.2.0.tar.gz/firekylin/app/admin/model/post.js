'use strict';
/**
 * relation model
 */

exports.__esModule = true;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = require('babel-runtime/helpers/inherits');

var _inherits3 = _interopRequireDefault(_inherits2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _class = function (_think$model$relation) {
  (0, _inherits3.default)(_class, _think$model$relation);

  function _class() {
    (0, _classCallCheck3.default)(this, _class);
    return (0, _possibleConstructorReturn3.default)(this, _think$model$relation.apply(this, arguments));
  }

  /**
   * init
   * @param  {} args []
   * @return {}         []
   */

  _class.prototype.init = function init() {
    var _think$model$relation2;

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    (_think$model$relation2 = _think$model$relation.prototype.init).call.apply(_think$model$relation2, [this].concat(args));

    this.relation = {
      tag: think.model.MANY_TO_MANY,
      cate: think.model.MANY_TO_MANY,
      user: {
        type: think.model.BELONG_TO,
        // fKey: 'user_id',
        // key: 'display_name',
        field: 'id,name,display_name'
      }
    };
  };

  /**
   * 添加文章
   * @param {[type]} data [description]
   * @param {[type]} ip   [description]
   */


  _class.prototype.addPost = function addPost(data) {
    var create_time = think.datetime();
    data = (0, _assign2.default)({
      type: 0,
      status: 0,
      create_time: create_time,
      update_time: create_time,
      is_public: 1
    }, data);

    return this.where({ pathname: data.pathname, _logic: 'OR' }).thenAdd(data);
  };

  _class.prototype.savePost = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee(data) {
      var info;
      return _regenerator2.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return this.where({ id: data.id }).find();

            case 2:
              info = _context.sent;

              if (!think.isEmpty(info)) {
                _context.next = 5;
                break;
              }

              return _context.abrupt('return', _promise2.default.reject(new Error('POST_NOT_EXIST')));

            case 5:
              data.update_time = think.datetime();
              return _context.abrupt('return', this.where({ id: data.id }).update(data));

            case 7:
            case 'end':
              return _context.stop();
          }
        }
      }, _callee, this);
    }));
    return function savePost(_x) {
      return ref.apply(this, arguments);
    };
  }();

  _class.prototype.addPostCate = function addPostCate(cate_ids) {};

  /**
   * get count posts
   * @param  {Number} userId []
   * @return {Promise}        []
   */


  _class.prototype.getCount = function getCount(userId) {
    if (userId) {
      return this.where({ user_id: userId }).count();
    }
    return this.count();
  };
  /**
   * get latest posts
   * @param  {Number} nums []
   * @return {}      []
   */


  _class.prototype.getLatest = function getLatest() {
    var nums = arguments.length <= 0 || arguments[0] === undefined ? 10 : arguments[0];

    return this.order('id DESC').where({
      create_time: { '<=': think.datetime() },
      is_public: 1, //公开
      type: 0, //文章
      status: 3 //已经发布
    }).limit(nums).setRelation(false).order('create_time DESC').select();
  };

  return _class;
}(think.model.relation);

exports.default = _class;