'use strict';

exports.__esModule = true;
exports.default = {
  admin: {
    reg: /^admin/
  },
  home: {}
};