'use strict';

exports.__esModule = true;
exports.default = {
  cluster_on: 1
};