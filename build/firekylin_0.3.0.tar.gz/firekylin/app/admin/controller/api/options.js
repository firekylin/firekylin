'use strict';

exports.__esModule = true;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = require('babel-runtime/helpers/inherits');

var _inherits3 = _interopRequireDefault(_inherits2);

var _base = require('./base.js');

var _base2 = _interopRequireDefault(_base);

var _speakeasy = require('speakeasy');

var _speakeasy2 = _interopRequireDefault(_speakeasy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _class = function (_Base) {
  (0, _inherits3.default)(_class, _Base);

  function _class() {
    (0, _classCallCheck3.default)(this, _class);
    return (0, _possibleConstructorReturn3.default)(this, _Base.apply(this, arguments));
  }

  /**
   * 获取
   * @return {[type]} [description]
   */

  _class.prototype.getAction = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee() {
      var type, model, options, secret;
      return _regenerator2.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              type = this.get('type');

              if (!(type === '2fa')) {
                _context.next = 12;
                break;
              }

              model = this.model('options');
              _context.next = 5;
              return model.getOptions();

            case 5:
              options = _context.sent;

              if (!(options.two_factor_auth.length === 32)) {
                _context.next = 10;
                break;
              }

              return _context.abrupt('return', this.success({
                otpauth_url: 'otpauth://totp/firekylin?secret=' + options.two_factor_auth,
                secret: options.two_factor_auth
              }));

            case 10:
              secret = _speakeasy2.default.generateSecret({
                length: 20,
                name: 'firekylin'
              });
              return _context.abrupt('return', this.success({
                otpauth_url: secret.otpauth_url,
                secret: secret.base32
              }));

            case 12:
              return _context.abrupt('return', this.success());

            case 13:
            case 'end':
              return _context.stop();
          }
        }
      }, _callee, this);
    }));
    return function getAction() {
      return ref.apply(this, arguments);
    };
  }();

  _class.prototype.postAction = function postAction() {
    var type = this.get('type');
    if (type === '2faAuth') {
      var data = this.post();
      var verified = _speakeasy2.default.totp.verify({
        secret: data.secret,
        encoding: 'base32',
        token: data.code,
        window: 2
      });
      return verified ? this.success() : this.fail('TWO_FACTOR_AUTH_ERROR_DETAIL');
    }
    return _Base.prototype.postAction.call(this, this);
  };
  /**
   * 更新选项
   * @return {[type]} [description]
   */


  _class.prototype.putAction = function () {
    var ref = (0, _asyncToGenerator3.default)(_regenerator2.default.mark(function _callee2() {
      var data, model, result;
      return _regenerator2.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              data = this.post();

              if (!think.isEmpty(data)) {
                _context2.next = 3;
                break;
              }

              return _context2.abrupt('return', this.fail('DATA_EMPTY'));

            case 3:
              model = this.model('options');
              _context2.next = 6;
              return model.updateOptions(data);

            case 6:
              result = _context2.sent;

              this.success(result);

            case 8:
            case 'end':
              return _context2.stop();
          }
        }
      }, _callee2, this);
    }));
    return function putAction() {
      return ref.apply(this, arguments);
    };
  }();

  return _class;
}(_base2.default);

exports.default = _class;